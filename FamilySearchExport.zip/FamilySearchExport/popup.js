const ID_RE = /\b[A-Z0-9]{4}-[A-Z0-9]{3,4}\b/;
const $ = (id) => document.getElementById(id);
const say = (t) => ($("status").textContent = t);

// Runs inside the FamilySearch page: collects the person IDs that are shown on it.
function scrapePage() {
  const re = /\b[A-Z0-9]{4}-[A-Z0-9]{3,4}\b/;
  const ids = new Set();
  document.querySelectorAll("a[href*='/tree/person/'], a[href*='/tree/pedigree/']").forEach((a) => {
    const m = (a.getAttribute("href") || "").match(re);
    if (m) ids.add(m[0]);
  });
  document.querySelectorAll("[data-testid],[id],[data-person-id],[data-pid]").forEach((el) => {
    for (const attr of ["data-person-id", "data-pid", "data-testid", "id"]) {
      const v = el.getAttribute(attr);
      const m = v && v.match(re);
      if (m && /person|pid|card|node/i.test(attr + v)) ids.add(m[0]);
    }
  });
  const rootMatch = location.href.match(re);
  return { ids: [...ids], root: rootMatch ? rootMatch[0] : null, url: location.href };
}

async function getToken() {
  const c = await chrome.cookies.get({ url: "https://www.familysearch.org", name: "fssessionid" });
  return c ? c.value : null;
}

async function fetchAncestry(root, token) {
  const url = `https://www.familysearch.org/platform/tree/ancestry?person=${root}&generations=8&personDetails=`;
  const res = await fetch(url, {
    headers: { Accept: "application/x-fs-v1+json", ...(token ? { Authorization: "Bearer " + token } : {}) },
    credentials: "include",
  });
  if (!res.ok) throw new Error(`FamilySearch returned ${res.status}. Make sure you are logged in.`);
  return res.json();
}

function splitName(p) {
  const parts = p.names?.[0]?.nameForms?.[0]?.parts || [];
  let given = parts.filter((x) => x.type?.endsWith("Given")).map((x) => x.value).join(" ");
  let sur = parts.filter((x) => x.type?.endsWith("Surname")).map((x) => x.value).join(" ");
  if (!given && !sur) {
    const full = p.display?.name || "Unknown";
    const bits = full.trim().split(/\s+/);
    sur = bits.length > 1 ? bits.pop() : "";
    given = bits.join(" ");
  }
  return { given, sur, full: p.display?.name || `${given} ${sur}`.trim() };
}

function buildPeople(data, pageIds, ignoreFilter) {
  const people = new Map(); // ascendancy number -> person
  for (const p of data.persons || []) {
    const n = parseInt(p.display?.ascendancyNumber, 10);
    if (!n) continue;
    if (!ignoreFilter && !pageIds.has(p.id)) continue;
    const nm = splitName(p);
    people.set(n, {
      n, id: p.id, ...nm,
      sex: p.gender?.type?.endsWith("Male") ? "M" : p.gender?.type?.endsWith("Female") ? "F" : "U",
      birthDate: p.display?.birthDate, birthPlace: p.display?.birthPlace,
      deathDate: p.display?.deathDate, deathPlace: p.display?.deathPlace,
      lifespan: p.display?.lifespan,
    });
  }
  return people;
}

function toGedcom(people) {
  const L = ["0 HEAD", "1 SOUR FSExporter", "2 NAME FamilySearch Tree Exporter", "1 GEDC", "2 VERS 5.5.1", "2 FORM LINEAGE-LINKED", "1 CHAR UTF-8"];
  const fams = [];
  for (const n of people.keys()) {
    const f = people.get(2 * n), m = people.get(2 * n + 1);
    if (f || m) fams.push({ child: n, f: f?.n, m: m?.n });
  }
  const famOfChild = new Map(fams.map((f, i) => [f.child, i + 1]));
  const famsOf = new Map();
  fams.forEach((f, i) => {
    for (const p of [f.f, f.m]) if (p) famsOf.set(p, [...(famsOf.get(p) || []), i + 1]);
  });
  for (const p of people.values()) {
    L.push(`0 @I${p.n}@ INDI`, `1 NAME ${p.given} /${p.sur}/`, `1 SEX ${p.sex}`);
    if (p.birthDate || p.birthPlace) {
      L.push("1 BIRT");
      if (p.birthDate) L.push(`2 DATE ${p.birthDate}`);
      if (p.birthPlace) L.push(`2 PLAC ${p.birthPlace}`);
    }
    if (p.deathDate || p.deathPlace) {
      L.push("1 DEAT");
      if (p.deathDate) L.push(`2 DATE ${p.deathDate}`);
      if (p.deathPlace) L.push(`2 PLAC ${p.deathPlace}`);
    }
    L.push(`1 _FSFTID ${p.id}`);
    if (famOfChild.has(p.n)) L.push(`1 FAMC @F${famOfChild.get(p.n)}@`);
    for (const fi of famsOf.get(p.n) || []) L.push(`1 FAMS @F${fi}@`);
  }
  fams.forEach((f, i) => {
    L.push(`0 @F${i + 1}@ FAM`);
    if (f.f) L.push(`1 HUSB @I${f.f}@`);
    if (f.m) L.push(`1 WIFE @I${f.m}@`);
    L.push(`1 CHIL @I${f.child}@`);
  });
  L.push("0 TRLR");
  return L.join("\n");
}

function toTxt(people) {
  return [...people.values()].sort((a, b) => a.n - b.n).map((p) => {
    const gen = Math.floor(Math.log2(p.n));
    const ind = "  ".repeat(gen);
    let s = `${ind}${p.n}. ${p.full} (${p.id})`;
    if (p.birthDate || p.birthPlace) s += `\n${ind}   Born: ${[p.birthDate, p.birthPlace].filter(Boolean).join(", ")}`;
    if (p.deathDate || p.deathPlace) s += `\n${ind}   Died: ${[p.deathDate, p.deathPlace].filter(Boolean).join(", ")}`;
    return s;
  }).join("\n\n");
}

function download(name, text, mime) {
  const url = URL.createObjectURL(new Blob([text], { type: mime }));
  const a = document.createElement("a");
  a.href = url; a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

$("go").addEventListener("click", async () => {
  $("go").disabled = true;
  try {
    say("Reading the page…");
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.url?.includes("familysearch.org")) throw new Error("Open your FamilySearch tree page first.");
    const [{ result }] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: scrapePage });
    const ignore = $("all").checked;
    if (!result.root) throw new Error("Couldn't find a person ID in the page URL. Open the tree view of the person you started from.");
    if (!ignore && result.ids.length === 0) throw new Error("No person cards found on the page. Send the page HTML to Claude so the selectors can be fixed, or tick the 'ignore page filter' box.");
    say(`Found ${result.ids.length} people on the page. Fetching their data…`);
    const data = await fetchAncestry(result.root, await getToken());
    const people = buildPeople(data, new Set([...result.ids, result.root]), ignore);
    if (!people.size) throw new Error("Nothing matched. Try ticking the 'ignore page filter' box.");
    const fmt = $("format").value;
    const base = `familysearch-tree-${result.root}`;
    if (fmt === "ged") download(base + ".ged", toGedcom(people), "text/plain");
    else if (fmt === "txt") download(base + ".txt", toTxt(people), "text/plain");
    else download(base + ".json", JSON.stringify([...people.values()], null, 2), "application/json");
    say(`Exported ${people.size} people.`);
  } catch (e) {
    say("Error: " + e.message);
  } finally {
    $("go").disabled = false;
  }
});
